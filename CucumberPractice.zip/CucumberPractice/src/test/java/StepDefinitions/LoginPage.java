package StepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage {
	
	WebDriver driver;
		
	@Given("I am on the login page")
	public void i_am_on_the_login_page() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.className("login")).click();
		}

	@When("I fill in Username with {string}")
	public void i_fill_in_Username_with(String userName) {
	    driver.findElement(By.id("email")).sendKeys(userName);
	}

	@When("I fill in Password with {string}")
	public void i_fill_in_Password_with(String passWord) {
		driver.findElement(By.id("passwd")).sendKeys(passWord);
	}

	@When("I press SignIn")
	public void i_press_Login() {
	    driver.findElement(By.id("SubmitLogin")).click();
	}

	@Then("I should be on the user account page and should see the message {string}")
	public void i_should_be_on_the_user_account_page_and_should_see_the_message(String message) {
	    String msg = driver.findElement(By.xpath("//*[@id=\'center_column\']/p")).getText();
	    if(msg.contains(message))
	    	System.out.println("User is on account page and logged in successfully");
	    else
	    	System.out.println("Something is not correct");
	}

	@And("I am logging out")
	public void i_am_logging_out() {
		driver.findElement(By.className("logout")).click();
		driver.quit();
	}

}
