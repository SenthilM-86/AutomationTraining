package TestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class dataProviderExample {
	WebDriver driver;

	@Test(dataProvider = "LoginData", dataProviderClass = customDataProvider.class)
	public void loginTest(String userName, String passWord) throws Exception {

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		driver.findElement(By.className("login")).click();
		driver.findElement(By.id("email")).sendKeys(userName);
		driver.findElement(By.id("passwd")).sendKeys(passWord);
		driver.findElement(By.id("SubmitLogin")).click();
		driver.findElement(By.className("logout")).click();
		driver.quit();
	}
}
